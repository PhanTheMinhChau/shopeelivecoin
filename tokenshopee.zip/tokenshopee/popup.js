const cookieDisplay = document.getElementById("cookieValue");
const copyBtn = document.getElementById("copyBtn");

let cookieContent = "";

chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  const url = new URL(tabs[0].url);

  if (!url.hostname.endsWith("shopee.vn")) {
    cookieDisplay.textContent = "Vui lòng di chuyển đến trang shopee.vn";
    copyBtn.disabled = true;
    return;
  }

  chrome.cookies.get({ url: "https://shopee.vn", name: "SPC_EC" }, function(cookie) {
    if (cookie) {
      cookieContent = cookie.value;
      cookieDisplay.textContent = cookieContent;
    } else {
      cookieDisplay.textContent = "Cookie SPC_EC không tồn tại.";
      copyBtn.disabled = true;
    }
  });
});

copyBtn.addEventListener("click", () => {
  if (cookieContent) {
    navigator.clipboard.writeText(cookieContent).then(() => {
      copyBtn.textContent = "Copied!";
      setTimeout(() => (copyBtn.textContent = "Copy"), 1500);
    });
  }
});
