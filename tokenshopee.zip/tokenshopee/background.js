chrome.cookies.onChanged.addListener(function(changeInfo) {
  console.log("Cookie changed: ", changeInfo);
});
